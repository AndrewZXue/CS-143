import library json to convert json file to txt; import sys library to output
use regular expression to sanitize the comments from database